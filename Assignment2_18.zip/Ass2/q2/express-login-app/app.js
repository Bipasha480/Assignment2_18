const express = require('express');
const session = require('express-session');
const flash = require('connect-flash');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 2000;

// Simple in-memory user store for demonstration purposes
const users = [{ username: 'Bipasha', password: 'BIPS' }];

// Setup session
app.use(session({
    secret: 'secret_key', // Replace with a strong secret in production
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60000 } // 1 minute
}));

// Flash messages middleware
app.use(flash());

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, 'public'))); // Serve static files

// Render login form
app.get('/login', (req, res) => {
    res.render('login', { messages: req.flash('error') });
});

// Handle login
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    // Check user credentials
    const user = users.find(u => u.username === username && u.password === password);
    if (user) {
        req.session.user = user;
        req.flash('success', 'Logged in successfully!');
        return res.redirect('/dashboard');
    }

    req.flash('error', 'Invalid username or password');
    res.redirect('/login');
});

// Render dashboard
app.get('/dashboard', (req, res) => {
    if (!req.session.user) {
        req.flash('error', 'Please log in first');
        return res.redirect('/login');
    }
    res.render('dashboard', { user: req.session.user });
});

// Logout
// Logout
app.get('/logout', (req, res) => {
    req.flash('success', 'Logged out successfully'); // Set flash message before destroying session
    req.session.destroy(err => {
        if (err) {
            return res.redirect('/dashboard'); // Handle session destruction error
        }
        res.redirect('/login'); // Redirect to login after session is destroyed
    });
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
