const express = require('express');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const cors = require('cors');
const path = require('path');
const session = require('express-session');
const methodOverride = require('method-override');
const app = express();
const PORT = process.env.PORT || 8000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(methodOverride('_method')); // For PUT and DELETE methods
app.use(cors());
app.set('view engine', 'ejs');

// Set views directory
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));

// Session setup
app.use(session({
    secret: 'your_secret_key',
    resave: false,
    saveUninitialized: true,
}));

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/employeeDB', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.error(err));

// Employee Schema
const employeeSchema = new mongoose.Schema({
    name: String,
    email: { type: String, unique: true },
    password: String
});

const Employee = mongoose.model('Employee', employeeSchema);

// Middleware for JWT verification
const authenticateJWT = (req, res, next) => {
    const token = req.session.token;
    if (!token) return res.redirect('/login'); // Redirect to login if not logged in

    jwt.verify(token, 'your_jwt_secret', (err, user) => {
        if (err) return res.redirect('/login'); // Redirect if token is invalid
        req.user = user;
        next();
    });
};

// Routes

// Registration Page
app.get('/register', (req, res) => {
    res.render('register');
});

// Register new employee
app.post('/register', async (req, res) => {
    const hashedPassword = await bcrypt.hash(req.body.password, 10);
    const newEmployee = new Employee({
        name: req.body.name,
        email: req.body.email,
        password: hashedPassword
    });

    try {
        await newEmployee.save();
        res.redirect('/login'); // Redirect to login page after registration
    } catch (error) {
        res.status(400).send('Error registering employee');
    }
});

// Login Page
app.get('/login', (req, res) => {
    res.render('login');
});

// Login employee
app.post('/login', async (req, res) => {
    const employee = await Employee.findOne({ email: req.body.email });
    if (employee && (await bcrypt.compare(req.body.password, employee.password))) {
        const token = jwt.sign({ email: employee.email }, 'your_jwt_secret', { expiresIn: '1h' });
        req.session.token = token;
        res.redirect('/employees'); // Redirect to the employee list page after login
    } else {
        res.status(403).send('Invalid credentials');
    }
});

// Logout
app.post('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) return res.status(500).send('Could not log out');
        res.redirect('/login');
    });
});

// View all employees (Protected route)
app.get('/employees', authenticateJWT, async (req, res) => {
    try {
        const employees = await Employee.find();
        res.render('employeeList', { employees });
    } catch (error) {
        res.status(500).send('Error retrieving employees');
    }
});

// Add employee form (Protected route)
app.get('/employees/new', authenticateJWT, (req, res) => {
    res.render('addEmployee');
});

// Handle adding a new employee
app.post('/employees', authenticateJWT, async (req, res) => {
    const hashedPassword = await bcrypt.hash(req.body.password, 10);
    const newEmployee = new Employee({
        name: req.body.name,
        email: req.body.email,
        password: hashedPassword
    });

    try {
        await newEmployee.save();
        res.redirect('/employees');
    } catch (error) {
        res.status(400).send('Error creating employee');
    }
});

// Update employee form (Protected route)
app.get('/employees/:id/edit', authenticateJWT, async (req, res) => {
    try {
        const employee = await Employee.findById(req.params.id);
        res.render('editEmployee', { employee });
    } catch (error) {
        res.status(400).send('Error retrieving employee');
    }
});

// Handle updating an employee
app.put('/employees/:id', authenticateJWT, async (req, res) => {
    const updateData = {
        name: req.body.name,
        email: req.body.email,
    };

    if (req.body.password) {
        updateData.password = await bcrypt.hash(req.body.password, 10);
    }

    try {
        await Employee.findByIdAndUpdate(req.params.id, updateData);
        res.redirect('/employees');
    } catch (error) {
        res.status(400).send('Error updating employee');
    }
});

// Handle deleting an employee
app.delete('/employees/:id', authenticateJWT, async (req, res) => {
    try {
        await Employee.findByIdAndDelete(req.params.id);
        res.redirect('/employees');
    } catch (error) {
        res.status(400).send('Error deleting employee');
    }
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
